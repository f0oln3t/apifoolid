"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { loginWithGithub, logout } from "@/lib/auth";
import { useToast } from "./Toast";

export default function Navbar() {
  const { user, loading } = useAuth();
  const pathname = usePathname();
  const showToast = useToast();

  async function handleLogin() {
    try {
      const u = await loginWithGithub();
      showToast(`Login berhasil sebagai ${u.displayName || "kamu"}`);
    } catch (err) {
      console.error(err);
      showToast("Login gagal: " + (err.message || err.code));
    }
  }

  async function handleLogout() {
    await logout();
    showToast("Kamu sudah logout");
  }

  return (
    <div className="topbar">
      <div className="topbar-inner">
        <Link href="/" className="brand">
          <span className="dot">$</span> APi.foolid <span className="brand-tag">v1</span>
        </Link>
        <nav className="nav-links">
          <Link href="/" className={pathname === "/" ? "active" : ""}>
            Direktori
          </Link>
          <Link href="/submit" className={pathname === "/submit" ? "active" : ""}>
            ShareSnippet
          </Link>
          <a href="https://github.com/f0oln3t/apifoolid" target="_blank" rel="noopener noreferrer">
            Ikut kontribusi
          </a>
        </nav>
        <div>
          {loading ? null : user ? (
            <div className="user-chip">
              {user.photoURL ? (
                <Image src={user.photoURL} alt="" width={24} height={24} style={{ borderRadius: "50%" }} />
              ) : null}
              <span>{user.displayName || "Kamu"}</span>
              <button className="btn btn-ghost" onClick={handleLogout}>
                Keluar
              </button>
            </div>
          ) : (
            <button className="btn btn-primary" onClick={handleLogin}>
              <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
              </svg>
              Login GitHub
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
